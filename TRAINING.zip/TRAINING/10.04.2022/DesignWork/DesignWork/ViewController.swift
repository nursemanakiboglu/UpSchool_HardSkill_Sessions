//
//  ViewController.swift
//  DesignWork
//
//  Created by Nursema Nakiboğlu on 10.04.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Pizza"
        
        let appearence = UINavigationBarAppearance()
        
        //arka plan rengi
        appearence.backgroundColor = UIColor(named: "anaRenk")
        
        //Başlık rengi
        appearence.titleTextAttributes = [.foregroundColor : UIColor(named: "yaziRenk1")!,NSAttributedString.Key.font: UIFont(name: "Pacifico-Regular", size: 22)!]
        
        //Status bar
        navigationController?.navigationBar.barStyle = .black
        
        navigationController?.navigationBar.isTranslucent = true
        
        navigationController?.navigationBar.standardAppearance
        = appearence
        navigationController?.navigationBar.compactAppearance
        = appearence
        navigationController?.navigationBar.scrollEdgeAppearance
        = appearence
        
    }


}

