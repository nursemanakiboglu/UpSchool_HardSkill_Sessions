//
//  UlkeCollectionViewCell.swift
//  CollectionViewKullanimi
//
//  Created by Nursema Nakiboğlu on 6.05.2022.
//

import UIKit

class UlkeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var ulkeLabel: UILabel!
}
