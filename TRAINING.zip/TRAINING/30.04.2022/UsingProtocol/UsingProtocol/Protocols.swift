//
//  Protocols.swift
//  UsingProtocol
//
//  Created by Nursema Nakiboğlu on 8.05.2022.
//

import Foundation

//Protokol oluştutuldu
//DetailVC'den View Controller'a geçiş yapılacak
protocol DetailVCtoViewController
{
    //veri gönderme işlemini yapcak bir fonksiyon oluşturma
    //string türünde mesaj gönderir
    func veriGonder(mesaj:String)
    
}
