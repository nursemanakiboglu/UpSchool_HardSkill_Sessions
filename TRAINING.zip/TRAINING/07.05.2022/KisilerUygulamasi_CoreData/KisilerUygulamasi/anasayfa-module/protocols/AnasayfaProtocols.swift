//
//  AnasayfaProtocols.swift
//  KisilerUygulamasi
//
//  Created by Nursema Nakiboğlu on 12.05.2022.
//

import Foundation

//Ana protocoller
protocol ViewToPresenterAnasayfaProtocol
{
    var anasayfaInteractor:PresenterToInteractorAnasayfaProtocol? {get set}
    var anasayfaView:PresenterToViewAnasayfaProtocol? {get set}
    
    func kisileriYukle()
    func ara(aramaKelimesi:String)
    func sil(kisi:KisilerModel)
}

protocol PresenterToInteractorAnasayfaProtocol
{
    var anasayfaPresenter:InteractorToPresenterAnasayfaProtocol? {get set}
    
    func tumKisileriAl()
    func kisiAra(aramaKelimesi:String)
    func kisiSil(kisi:KisilerModel)
}

//Taşıyıcı protocoller
protocol InteractorToPresenterAnasayfaProtocol
{
    func presenteraVeriGonder(kisilerListesi:Array<KisilerModel>)
}

protocol PresenterToViewAnasayfaProtocol
{
    func vieweVeriGonder(kisilerListesi:Array<KisilerModel>)
}

//Router protocol
protocol PresenterToRouterAnasayfaProtocol
{
    static func createModule(ref:AnasayfaVC)
}
