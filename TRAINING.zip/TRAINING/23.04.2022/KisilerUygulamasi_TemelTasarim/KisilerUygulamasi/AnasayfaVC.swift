//
//  AnasayfaVC.swift
//  KisilerUygulamasi
//
//  Created by Nursema Nakiboğlu on 10.05.2022.
//

import UIKit

class AnasayfaVC: UIViewController
{
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var kisilerTableView: UITableView!
    
    var kisilerListe = [Kisiler]() //veri kümesi oluşturma
    
    override func viewDidLoad()
    {
        //yetkilendirme
        super.viewDidLoad()
        searchBar.delegate = self
        kisilerTableView.delegate = self
        kisilerTableView.dataSource = self
        
        let k1 = Kisiler(kisi_id: 1, kisi_ad: "Ahmet", kisi_tel: "11111")
        let k2 = Kisiler(kisi_id: 2, kisi_ad: "Zeynep", kisi_tel: "22222")
        
        //listeye ekleme
        kisilerListe.append(k1)
        kisilerListe.append(k2)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "toDetay"
        {
            let kisi = sender as? Kisiler
            let gidilecekVC = segue.destination as! KisiDetayVC
            gidilecekVC.kisi = kisi
        }
    }
}

//Extension; başka bir swift dosyası oluşturularak da kullanılabilir.
//anasayfanın devamıdır
//sınıf ismi ile aynı olarak genişletme yapılır
extension AnasayfaVC : UISearchBarDelegate
{
    //arama işlemini yapan kısım
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        print("Arama Sonucu : \(searchText)")
    }
}

extension AnasayfaVC : UITableViewDelegate,UITableViewDataSource
{
    //bölüm içerisindeki satır sayısı
    //indexpath ile sıralayla veri bilgileri alınıp tek tek çoğaltılır.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return kisilerListe.count
    }
    
    //trailing demek sol tarafı temsil eder demektir.
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let kisi = kisilerListe[indexPath.row]
        let hucre = tableView.dequeueReusableCell(withIdentifier: "kisilerHucre", for: indexPath) as! TableViewHucre
        hucre.kisiBilgiLabel.text = "\(kisi.kisi_ad!) - \(kisi.kisi_tel!)"
        return hucre
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let kisi = kisilerListe[indexPath.row]
        performSegue(withIdentifier: "toDetay", sender: kisi)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        
        let silAction = UIContextualAction(style: .destructive, title: "Sil")
        { (action,view,bool) in
            let kisi = self.kisilerListe[indexPath.row]
            
            //silme işlemine tıkladıktan sonra soru sorduruyoruz.
            let alert = UIAlertController(title: "Silme İşlemi", message: "\(kisi.kisi_ad!) silinsin mi ?", preferredStyle: .alert)
            
            let iptalAction = UIAlertAction(title: "İptal", style: .cancel){ action in }
            alert.addAction(iptalAction)
            
            let evetAction = UIAlertAction(title: "Evet", style: .destructive)
            { action in
                print("\(kisi.kisi_ad!) silindi")
            }
            alert.addAction(evetAction)
            
            self.present(alert, animated: true)
            
        }
        //silme işlemi
        return UISwipeActionsConfiguration(actions: [silAction])
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath)
    {
        let kisi = kisilerListe[indexPath.row]
        // print("\(kisi.kisi_ad!) seçildi")
        // tableView.deselectRow(at: indexPath, animated: true)
        //yukardaki iki işlem satırların üstüne gelindiğinde seçili olan rengi kaldırır
        performSegue(withIdentifier: "toDetay", sender: kisi)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

