//
//  UrunTableViewCell.swift
//  DetayliTableViewKullanimi1
//
//  Created by Nursema Nakiboğlu on 3.05.2022.
//

import UIKit

protocol HucreProtocol //protokol tanımlandı
{
    func buttonTiklandi(indexPath:IndexPath)//Butona tıklanmasını temsil eden çatı protokol //index path değerleri iletilmeli ki hangi ürünü sepete eklediğimiz anlaşılsın
}

class UrunTableViewCell: UITableViewCell
{
    @IBOutlet weak var urunResimImageView: UIImageView!
    @IBOutlet weak var urunAdlabel: UILabel!
    @IBOutlet weak var urunFiyatlabel: UILabel!
    @IBOutlet weak var hucreArkaPlan: UIView!
    
    var hucreProtocol:HucreProtocol? //bu nesneyi view controller da yetkilendiriyoruz
    var indexPath:IndexPath? //bu nesneyi view controller da yetkilendiriyoruz
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }

    @IBAction func sepeteekleButon(_ sender: Any) //butonu çalıştıracağımız kısım
    {
        //print("Buton Tıklandı") //sadece bunu kullanısak bütün ürünlerde aynı işlevi yapıcak ama hangi ürünü seçtiğimizi anlamıcak bu yüzden sayfalar arası geçişleri sağlıyacak protokole ihtiyacımız var
        
        hucreProtocol?.buttonTiklandi(indexPath: indexPath!)
    }
}
