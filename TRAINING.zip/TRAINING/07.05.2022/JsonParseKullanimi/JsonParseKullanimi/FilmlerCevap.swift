//
//  FilmlerCevap.swift
//  JsonParseKullanimi
//
//  Created by Nursema Nakiboğlu on 18.05.2022.
//

import Foundation

class FilmlerCevap : Codable
{
    var filmler:[Filmler]?
    var success:Int?
}
