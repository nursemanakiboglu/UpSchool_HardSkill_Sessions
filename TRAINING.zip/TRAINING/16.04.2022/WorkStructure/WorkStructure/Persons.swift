//
//  Persons.swift
//  WorkStructure
//
//  Created by Nursema Nakiboğlu on 21.04.2022.
//

import Foundation

class Persons
{
    var name:String?
    var age:Int?
    var height:Double?
    var single:Bool?
    
    init(name:String,age:Int,height:Double,single:Bool)
    {
        self.name = name
        self.age = age
        self.height = height
        self.single = single
    }
}
