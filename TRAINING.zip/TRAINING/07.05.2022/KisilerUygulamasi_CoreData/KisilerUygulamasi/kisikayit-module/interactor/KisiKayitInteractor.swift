//
//  KisiKayitInteractor.swift
//  KisilerUygulamasi
//
//  Created by Nursema Nakiboğlu on 10.05.2022.
//

import Foundation
import CoreData

class KisiKayitInteractor : PresenterToInteractorKisiKayitProtocol
{
    let context = appDelegate.persistentContainer.viewContext
    
    func kisiEkle(kisi_ad: String, kisi_tel: String)
    {
        //nesne oluşturma
        let kisi = KisilerModel(context: context)
        kisi.kisi_ad = kisi_ad
        kisi.kisi_tel = kisi_tel
        appDelegate.saveContext()
    }
    
}
