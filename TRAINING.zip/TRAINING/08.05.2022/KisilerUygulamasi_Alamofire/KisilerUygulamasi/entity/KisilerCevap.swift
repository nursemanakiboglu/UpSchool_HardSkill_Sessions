//
//  KisilerCevap.swift
//  KisilerUygulamasi
//
//

import Foundation

class KisilerCevap : Codable {
    var kisiler:[Kisiler]?
    var success:Int?
}
