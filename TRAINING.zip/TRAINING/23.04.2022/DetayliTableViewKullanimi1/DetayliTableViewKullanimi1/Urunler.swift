//
//  Urunler.swift
//  DetayliTableViewKullanimi1
//
//  Created by Nursema Nakiboğlu on 3.05.2022.
//

import Foundation

class Urunler
{
    var urun_id:Int?
    var urun_ad:String?
    var urun_resim_ad:String?
    var urun_fiyat:Double?
    
    //init methodu
    
    init(urun_id:Int,urun_ad:String,urun_resim_ad:String,urun_fiyat:Double)
    {
        self.urun_id = urun_id
        self.urun_ad = urun_ad
        self.urun_resim_ad = urun_resim_ad
        self.urun_fiyat = urun_fiyat
    }
}
