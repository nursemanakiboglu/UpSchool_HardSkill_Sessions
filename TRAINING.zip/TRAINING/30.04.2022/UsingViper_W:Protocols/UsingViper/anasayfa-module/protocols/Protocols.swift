//
//  Protocols.swift
//  UsingViper
//
//  Created by Nursema Nakiboğlu on 30.04.2022.
//

import Foundation

//View -- Presenter -- Interactor

//ana protocoller
protocol ViewToPresenterProtocol//view ile presenter arasındaki yapı oluşur
{
    var interactor:PresenterToInteractorProtocol? {get set}
    var view:PresenterToViewProtocol? {get set}
    
    func toplamaYap(sayi1:String,sayi2:String)
    func carpmaYap(sayi1:String,sayi2:String)}

protocol PresenterToInteractorProtocol // presenter ile interactor arasındaki yapı oluşur
{
    var presenter:InteractorToPresenterProtocol? {get set}
    
    func topla(sayi1:String,sayi2:String)
    func carp(sayi1:String,sayi2:String)
}
//Taşıyıcı protocoller

protocol InteractorToPresenterProtocol
{
    func presanteraVeriGönder(sonuc:String)
}

protocol PresenterToViewProtocol
{
    func vieweVeriGönder(sonuc:String)
    
}

//Router Protocol

protocol PresenterToRouterProtocol
{
    static func createModule(ref:ViewController) //modulümüzün view katmanı hangsiyse bunu yazıyoruz
    
}
