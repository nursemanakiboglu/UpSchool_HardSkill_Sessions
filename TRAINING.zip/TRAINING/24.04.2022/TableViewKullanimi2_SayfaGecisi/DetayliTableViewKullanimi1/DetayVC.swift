//
//  DetayVC.swift
//  DetayliTableViewKullanimi1
//
//  Created by Nursema Nakiboğlu on 6.05.2022.
//

import UIKit

class DetayVC: UIViewController
{

    @IBOutlet weak var urunResim: UIImageView!
    @IBOutlet weak var urunFiyat: UILabel!
    
    var urun:Urunler? //ürün nesnesi beklediğimizi belirtmemiz gerekiyor.
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //sayfa açıldığı anda yukarıda tanımladığımız ürün nesnesini kullanıyoruz bu yüzden viewDidloadun içerisinde belirtiyoruz.
        if let u = urun
        {
            self.navigationItem.title = u.urun_ad
            urunResim.image = UIImage(named: u.urun_resim_ad!)
            urunFiyat.text = " \(u.urun_fiyat!) TL "
        }

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func sepeteEkle(_ sender: Any)
    {
        if let u = urun
        {
            print(" \(u.urun_ad!) sepete eklendi ")
        }
    }
}
