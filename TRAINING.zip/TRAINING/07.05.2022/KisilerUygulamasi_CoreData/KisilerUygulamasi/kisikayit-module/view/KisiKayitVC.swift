//
//  KisiKayitVC.swift
//  KisilerUygulamasi
//
//  Created by Nursema Nakiboğlu on 10.05.2022.
//

import UIKit

class KisiKayitVC: UIViewController
{

    @IBOutlet weak var tfKisiAd: UITextField!
    @IBOutlet weak var tfKisiTel: UITextField!
    
    var kisiKayitPresenterNesnesi:ViewToPresenterKisiKayitProtocol?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        KisiKayitRouter.createModule(ref: self)
    }
    
    @IBAction func buttonKaydet(_ sender: Any)
    {
        if let ka = tfKisiAd.text,let kt = tfKisiTel.text
        {
            kisiKayitPresenterNesnesi?.ekle(kisi_ad: ka, kisi_tel: kt)
           // kayit(kisi_ad: ka, kisi_tel: kt)
        }
    }
    /*
     
     Protokol sayesinde bu fonksiyona ihtiyacımız yoktur.
    
    func kayit(kisi_ad:String,kisi_tel:String)
    {
        print("Kişi Kayıt : \(kisi_ad) - \(kisi_tel)")
    }
    */
}
