import UIKit

//override olması için inheritence olması gerek yani sınıflar arası ilişki olmalı

class Hayvan
{
    func sesCikar()
    {
        print("sesim yok")
    }
}

class Memeli: Hayvan
{
    
}

class Kedi: Memeli
{
    override func sesCikar()
    {
        print("miyav miyav")
    }
}

class Köpek: Memeli
{

}

var hayvan = Hayvan()
var memeli = Memeli()
var kedi = Kedi()
var köpek = Köpek()

hayvan.sesCikar()
memeli.sesCikar()
kedi.sesCikar()
köpek.sesCikar()

//Extension
//Kotlin  infix donksiyon

extension Int{
    func carp (sayi : Int) Int
       return self sayi
}
