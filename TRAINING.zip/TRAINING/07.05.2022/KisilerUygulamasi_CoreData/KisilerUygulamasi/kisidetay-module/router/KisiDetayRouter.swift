//
//  KisiDetayRouter.swift
//  KisilerUygulamasi
//
//  Created by Nursema Nakiboğlu on 10.05.2022.
//

import Foundation

class KisiDetayRouter : PresenterToRouterKisiDetayProtocol
{
    static func createModule(ref: KisiDetayVC)
    {
        ref.kisiDetayPresenterNesnesi = KisiDetayPresenter()
        ref.kisiDetayPresenterNesnesi?.kisiDetayInteractor = KisiDetayInteractor()
    }
}
