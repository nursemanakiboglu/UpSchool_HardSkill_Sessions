//
//  KisiKayitRouter.swift
//  KisilerUygulamasi
//
//  Created by Nursema Nakiboğlu on 10.05.2022.
//

import Foundation

class KisiKayitRouter : PresenterToRouterKisiKayitProtocol
{
    static func createModule(ref: KisiKayitVC)
    {
        ref.kisiKayitPresenterNesnesi = KisiKayitPresenter()
        ref.kisiKayitPresenterNesnesi?.kisiKayitInteractor = KisiKayitInteractor()
    }
}
