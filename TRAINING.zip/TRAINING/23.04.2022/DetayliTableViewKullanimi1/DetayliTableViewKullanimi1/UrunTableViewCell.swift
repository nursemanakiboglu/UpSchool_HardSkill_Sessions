//
//  UrunTableViewCell.swift
//  DetayliTableViewKullanimi1
//
//  Created by Nursema Nakiboğlu on 3.05.2022.
//

import UIKit

class UrunTableViewCell: UITableViewCell
{
    @IBOutlet weak var urunResimImageView: UIImageView!
    @IBOutlet weak var urunAdlabel: UILabel!
    @IBOutlet weak var urunFiyatlabel: UILabel!
    @IBOutlet weak var hucreArkaPlan: UIView!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    @IBAction func sepeteekleButon(_ sender: Any)
    {
        
    }
}
