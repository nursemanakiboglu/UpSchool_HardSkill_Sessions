//
//  ViewController.swift
//  TabBarControllerKullanimi
//
//  Created by Nursema Nakiboğlu on 21.04.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if let tabItems = tabBarController?.tabBar.items
        {
            let item = tabItems[1] //hangi sayfaya bildiri geldiğini gösterir
            item.badgeValue = "2"
        }
        
        let appearance = UITabBarAppearance() //arkaplan rengi
        appearance.backgroundColor = UIColor.lightGray
        
        itemRenkDegistir(itemAppearance: appearance.stackedLayoutAppearance)
        itemRenkDegistir(itemAppearance: appearance.inlineLayoutAppearance)
        itemRenkDegistir(itemAppearance: appearance.compactInlineLayoutAppearance)
        
        
        tabBarController?.tabBar.standardAppearance = appearance
        tabBarController?.tabBar.scrollEdgeAppearance = appearance

    }
    
    func itemRenkDegistir(itemAppearance:UITabBarItemAppearance)
    {
        //seçili olmayan durum rengi
        itemAppearance.normal.iconColor = UIColor.white
        itemAppearance.normal.titleTextAttributes = [ NSAttributedString.Key.foregroundColor:UIColor.white]
        itemAppearance.normal.badgeBackgroundColor = UIColor.red
        
        //seçili olan durum rengi
        itemAppearance.selected.iconColor = UIColor.yellow
        itemAppearance.selected.titleTextAttributes = [ NSAttributedString.Key.foregroundColor:UIColor.yellow]
        itemAppearance.selected.badgeBackgroundColor = UIColor.blue
    }


}

