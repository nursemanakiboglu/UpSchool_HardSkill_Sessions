//
//  ViewController.swift
//  PersonalApplication
//
//  Created by Nursema Nakiboğlu on 17.04.2022.
//

import UIKit

class AnasayfaVC: UIViewController {

    @IBOutlet weak var kisilerTableView: UITableView!
    @IBOutlet weak var searchBsr: UISearchBar!
    
    var kisilerListe = [Kisiler]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBsr.delegate = self
        
        let k1 = Kisiler(kisi_id: 1, kisi_ad: "Zeynep", kisi_tel: "111111")
        let k2 = Kisiler(kisi_id: 1, kisi_ad: "ırmak", kisi_tel: "222222")
        let k3 = Kisiler(kisi_id: 1, kisi_ad: "kübra", kisi_tel: "333333")
        let k4 = Kisiler(kisi_id: 1, kisi_ad: "melis", kisi_tel: "444444")
        
    }
    
    @IBAction func buttonDetay(_ sender: Any)
    {
        let kisi = Kisiler(kisi_id: 1, kisi_ad: "Zeynep", kisi_tel: "11111")
        performSegue(withIdentifier: "toDetay", sender: kisi)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "toDetay"
        {
            if let kisi = sender as? Kisiler
            {
                let gidilecekVC = segue.destination as! KisiDetayVC
                gidilecekVC.kisi = kisi
            }
        }
    }
}
extension AnasayfaVC:UISearchBarDelegate
{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        print("Arama Saonucu \(searchText)")
    }
}
