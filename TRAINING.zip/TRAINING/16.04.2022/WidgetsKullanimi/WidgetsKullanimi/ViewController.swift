//
//  ViewController.swift
//  WidgetsKullanimi
//
//  Created by Nursema Nakiboğlu on 22.04.2022.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var labelResult: UILabel!
    
    @IBOutlet weak var textfieldInput: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func buttonDo(_ sender: Any)
    {
        if let receivedData = textfieldInput.text //text methodu çift taraflı çalışır hem veri alır hem de veri gönderir
        {
            labelResult.text = receivedData
        }
    }
}

