//
//  Filmler.swift
//  JsonParseKullanimi
//
//  Created by Nursema Nakiboğlu on 18.05.2022.
//

import Foundation

class Filmler : Codable
{
    var film_id:String?
    var film_ad:String?
    var film_yil:String?
    var film_resim:String?
    var kategori:Kategoriler?
    var yonetmen:Yonetmenler?
}
