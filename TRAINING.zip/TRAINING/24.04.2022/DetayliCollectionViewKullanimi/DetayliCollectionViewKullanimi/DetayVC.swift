//
//  DetayVC.swift
//  DetayliCollectionViewKullanimi
//
//  Created by Nursema Nakiboğlu on 06.05.2022.
//

import UIKit

class DetayVC: UIViewController
{
    @IBOutlet weak var filmAdiLabel: UILabel!
    @IBOutlet weak var filmYonetmenAdiLabel: UILabel!
    @IBOutlet weak var filmFiyatLabel: UILabel!
    @IBOutlet weak var filmImageView: UIImageView!
    
    //nesne oluştur
    var film:Filmler?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //herbir filmi farklı sayfada açmak için tanımlamalar
        if let f = film
        {
            filmAdiLabel.text = f.filmAdi
            filmYonetmenAdiLabel.text = f.filmYonetmenAdi
            filmImageView.image = UIImage(named: f.filmResimAdi!)
            filmFiyatLabel.text = "\(f.filmFiyat!) ₺"
        }
    }
    @IBAction func sepeteEkleButton(_ sender: Any)
    {
        if let f = film
        {
            print("\(f.filmAdi!) sepete eklendi")
        }
    }
}
