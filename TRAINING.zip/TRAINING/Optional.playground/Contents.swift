import UIKit

var greeting = "Hello, playground"

//Boş değişken oluşturma
var str1:String? = nil

//tercih edilen
var str2:String?

var str3:String?

str2 = "Hello"

if str2 != nil{
    print(str2)
}else{
    print("str nil değer içeriyor1")
}

if str3 != nil{
    print(str2!) //optional unwrapping
}else{
    print("str nil değer içeriyor2")
}
