//
//  ViewController.swift
//  JsonParseKullanimi
//
//  Created by Nursema Nakiboğlu on 18.05.2022.
//

import UIKit

class ViewController: UIViewController
{

    override func viewDidLoad() {
        super.viewDidLoad()
        parseIslemi()
        // Do any additional setup after loading the view.
    }
    
    func parseIslemi()
    {
        let url = URL(string: "http://kasimadalan.pe.hu/filmler/tum_filmler.php")!
        
        URLSession.shared.dataTask(with: url)
        {
            data,response,error in
            
            if error != nil || data == nil
            {
                print("Hata")
                
                return
            }
            
            do
            {
                //veriyi getirecek
                //let json = try JSONSerialization.jsonObject(with: data!)
                //print(json)
                
                let cevap = try JSONDecoder().decode(FilmlerCevap.self, from: data!)
                if let basari = cevap.success
                {
                    print( "Başarı : \(basari)")
                }
                
                if let filmler = cevap.filmler
                {
                    for f in filmler
                    {
                        print("Film id : \(f.film_id!)")
                        print("Film ad : \(f.film_ad!)")
                        print("Film yıl : \(f.film_yil!)")
                        print("Film resim: \(f.film_resim!)")
                        print("Film id : \(f.kategori!.kategori_ad!)")
                        print("Film id : \(f.yonetmen!.yonetmen_ad!)")
                    }
                }
            }
            catch
            {
                print(error.localizedDescription)
            }
        }.resume()
    }


}

