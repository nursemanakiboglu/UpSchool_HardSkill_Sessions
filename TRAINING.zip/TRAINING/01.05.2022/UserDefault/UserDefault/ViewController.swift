//
//  ViewController.swift
//  UserDefault
//
//  Created by Nursema Nakiboğlu on 1.05.2022.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var labelSayac: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let ud = UserDefaults.standard
        
        //KAYIT
        ud.set("Gizem", forKey: "ad")
        ud.set(23, forKey: "ad")
        ud.set(1.78, forKey: "ad")
        ud.set(true, forKey: "bekar")
        
        let liste = ["ali","ece"]
        ud.set(liste, forKey: "liste")
        
        let sehirler = ["16":"BURSA", "34":"İSTANBUL"]
        ud.set(sehirler, forKey: "sehirler")
        
        //Silme
        //ud.removeObject(forKey: "ad")
        
        //Okuma
        let gelenAd = ud.string(forKey: "ad") ?? "isim yok" // iki tane soru işareti demek varsayılan değer anlamına gelir yani biri olmassa diğerini kullan gibi bir ifadedir.
        let gelenYas = ud.integer(forKey: "yas") //varsayılan değeri 0
        let gelenBoy = ud.integer(forKey: "boy") //varsayılan değeri 0.0
        let gelenBekar = ud.integer(forKey: "bekar") //varsayılan değeri false
        
        print("Gelen Ad: \(gelenAd)")
        print("Gelen Yaş: \(gelenYas)")
        print("Gelen Boy: \(gelenBoy)")
        print("Gelen Bekar: \(gelenBekar)")
        
        let gelenListe = ud.array(forKey: "liste") ?? [String]()
        
        for a in gelenListe
        {
            print("Gelen Arkadaş : \(a)")
        }
        
        let gelenSehirler = ud.dictionary(forKey: "sehirler") ?? [String:String]()
        
        for (anahtar,deger) in gelenSehirler
        {
            print("Gelen şehir : \(anahtar) - \(deger) ")
        }
        
        //sayaç uygulaması
        
        var sayac = ud.integer(forKey: "sayac")
        
        sayac = sayac + 1
        
        ud.set(sayac, forKey: "sayac")
        
        labelSayac.text = "Açılış Sayısı : \(sayac) "

    }
}

