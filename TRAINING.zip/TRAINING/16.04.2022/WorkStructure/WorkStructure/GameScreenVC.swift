//
//  GameScreenVC.swift
//  WorkStructure
//
//  Created by Nursema Nakiboğlu on 20.04.2022.
//

import UIKit

class GameScreenVC: UIViewController
{
    var person:Persons?

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true // otomatik olarak oluşan back butonunu kaldırır
        
        if let p = person
        {
            print("Person name: \(p.name!)")
            print("Person age: \(p.age!)")
            print("Person height: \(p.height!)")
            print("Person single: \(p.single!)")
        }
    }
    
    @IBAction func finishClick(_ sender: Any)
    {
        performSegue(withIdentifier: "switchtoresultscreen", sender: nil)
    }
  
    @IBAction func backClick(_ sender: Any)
    {
        
            navigationController?.popViewController(animated: true) //pop ile bir geri dönüş yapılır (backstack)
        
        // eğerki çok fazla sayfa varsa ve hemen anasayfaya gelmek istiyorsak ozaman şu kod uygulanmalıdır; navigationController?.popToRootViewController(animated:true)
    }
  
}
