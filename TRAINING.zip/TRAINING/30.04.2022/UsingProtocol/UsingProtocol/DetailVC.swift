//
//  DetailVC.swift
//  UsingProtocol
//
//  Created by Nursema Nakiboğlu on 30.04.2022.
//

import UIKit

class DetailVC: UIViewController
{

    @IBOutlet weak var textFieldGirdi: UITextField!
    
    //protokol methodu tetiklendi
    //veri göndermek için protokolden bir nesneye ihtiyaç var oyüzden bir nesne tanımlanıyor
    var delegate:DetailVCtoViewController?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func butonGonder(_ sender: Any)
    {
        //sayfadaki text fielden veri alma
        if let mesaj = textFieldGirdi.text
        {
            delegate?.veriGonder(mesaj: mesaj)
        }
    }
}
