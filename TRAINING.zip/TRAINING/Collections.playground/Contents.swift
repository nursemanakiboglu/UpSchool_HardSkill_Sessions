import UIKit

var greeting = "Hello, playground"

//array verileri sıralı ekler
//set verileri karışık ekler//dictionaryi index yok keyleri ve valuelerş sen oluşrur

var numaralar = [ 10,0,5]
var sayilar = [Int](repeating: 0, count: 1000)


var meyveler = [String]()

//veri ekeleme
//append sona ekleme
meyveler.append("Elma")
meyveler.append("Portakal")

print(meyveler)

//güncelleme
meyveler[ 0 ] = "Yeni Elma"
print(meyveler)

//Insert araya ekleme
meyveler.insert("Muz", at:1)
print(meyveler)

print(meyveler.isEmpty) //Boş mu?
print(meyveler.count) //boyut

meyveler.append("Kivi")
print(meyveler)

print(meyveler.first!) //0. veya ilk eleman
print(meyveler.last!) //son indeks elemanı
print(meyveler.contains("Elma")) //içerik bulma

for meyve in meyveler
{
    print("Sonuc\(meyve)")
}

for (index,meyve) in meyveler.enumerated()
{
    print("\(index). -\(meyve)")
}

meyveler.remove(at: 1)
print(meyveler)

meyveler.removeAll()
print(meyveler)

class Ogrenciler
{
    var no: Int?
    var ad: String?
    var sinif: String?
    
    init(no:Int,ad:String,sinif:String)
    {
        self.no = no
        self.ad = ad
        self.sinif = sinif
    }
}

var o1 = Ogrenciler(no: 200, ad: "Zeynep", sinif: "9C")
var o2 = Ogrenciler(no: 300, ad: "Arzu", sinif: "11Z")
var o3 = Ogrenciler(no: 100, ad: "Beyza", sinif: "12A")

var ogrencilerListesi = [Ogrenciler]()
ogrencilerListesi.append(o1)
ogrencilerListesi.append(o2)
ogrencilerListesi.append(o3)

for o in ogrencilerListesi
{
    print("No: \(o.no!) - Ad: \(o.ad!) - Sınıf: \(o.sinif!)")
}

//Filtreleme

var f1 = ogrencilerListesi.filter({ $0.no! > 100 })
print("Filtreleme 1")
for o in f1
{
    print("No : \(o.no!) - Ad: \(o.ad!) - Sınıf: \(o.sinif!)")
}

var f2 = ogrencilerListesi.filter({ $0.ad!.contains("y")})
print("Filtreleme 2")
for o in f2
{
    print("No : \(o.no!) - Ad: \(o.ad!) - Sınıf: \(o.sinif!)")
}
