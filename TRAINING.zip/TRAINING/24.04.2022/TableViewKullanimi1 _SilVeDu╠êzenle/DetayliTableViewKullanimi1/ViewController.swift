//
//  ViewController.swift
//  DetayliTableViewKullanimi1
//
//  Created by Nursema Nakiboğlu on 3.05.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var urunlerTableView: UITableView!
    
    var urunlerliste = [Urunler]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        urunlerTableView.delegate = self
        urunlerTableView.dataSource = self
        
        urunlerTableView.separatorColor = UIColor(white: 0.95, alpha: 1) // ayraçın rengi
       
        //Ürünler sınıfından nesne oluşturmak
        
        let u1 = Urunler(urun_id: 1, urun_ad: "Macbook Pro", urun_resim_ad: "bilgisayar", urun_fiyat: 37.999)
        let u2 = Urunler(urun_id: 2, urun_ad: "Ryban", urun_resim_ad: "gözlük", urun_fiyat: 1.999)
        let u3 = Urunler(urun_id: 3, urun_ad: "Sony ZX", urun_resim_ad: "kulaklık", urun_fiyat: 2.999)
        let u4 = Urunler(urun_id: 4, urun_ad: "Gio Armani", urun_resim_ad: "parfüm", urun_fiyat: 3.999)
        let u5 = Urunler(urun_id: 5, urun_ad: "Casio X", urun_resim_ad: "saat", urun_fiyat: 13.999)
        let u6 = Urunler(urun_id: 7, urun_ad: "IPhone 11", urun_resim_ad: "telefon", urun_fiyat: 13.999)
        
        urunlerliste.append(u1)
        urunlerliste.append(u2)
        urunlerliste.append(u3)
        urunlerliste.append(u4)
        urunlerliste.append(u5)
        urunlerliste.append(u6)
    }
}

extension ViewController : UITableViewDelegate,UITableViewDataSource,HucreProtocol //protokolü view kontrole eklediğimiz kısım
{
    //kaç tane veri işleniceğini buluyoruz
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return urunlerliste.count //6 kere çalışacak
    }
    
    //hücre için satır işlemleri yapılacak olan kısım
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let urun = urunlerliste[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "urunHucre", for: indexPath ) as! UrunTableViewCell
        
        cell.urunResimImageView.image = UIImage(named: urun.urun_resim_ad!)
        cell.urunAdlabel.text = urun.urun_ad
        cell.urunFiyatlabel.text = "\(urun.urun_fiyat!) TL"
        
        cell.backgroundColor = UIColor(white: 0.95, alpha: 1)
        
        //method nerde kullanılıyorsa orda yetkilendirilir
        cell.hucreProtocol = self //nesne yetkilendirildi
        cell.indexPath = indexPath // yetkilendirildi
        
        return cell
    }
    //trailing = sağ taraftan açılan bölme
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let urun = urunlerliste[indexPath.row]
        
        //silme işlemi gerçekleşir
        let silAction = UIContextualAction(style: .destructive, title: "Sil")
        {
            (action,view,void) in
            print("\(urun.urun_ad!) silindi")
        }
        
        //düzenleme işlemi gerçekleşir
        let duzenleAction = UIContextualAction(style: .normal, title: "Düzenle")
        {
            (action,view,void) in
            print("\(urun.urun_ad!) düzenlendi")
        }
        
        return UISwipeActionsConfiguration(actions: [silAction,duzenleAction])
    }
    
    func buttonTiklandi(indexPath: IndexPath)
    {
        let urun = urunlerliste[indexPath.row] //indexpath değeri ile içerisindeki değeri ürün nesnesinin içerisine alabileceğiz.
        print("\(urun.urun_ad!) sepete ekle") //protocolu view kontrolde kullandığımız kısım
    }
}
