//
//  Protocols.swift
//  UsingProtocol
//
//  Created by Nursema Nakiboğlu on 30.04.2022.
//

import Foundation

protocol DetayVCtoViewController
{
    func veriGonder(mesaj:String)
}
