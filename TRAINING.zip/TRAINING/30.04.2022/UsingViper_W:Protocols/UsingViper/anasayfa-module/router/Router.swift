//
//  Router.swift
//  UsingViper
//
//  Created by Nursema Nakiboğlu on 30.04.2022.
//

import Foundation

class Router : PresenterToRouterProtocol
{
    static func createModule(ref: ViewController)
    {
        let presenter = Presenter()
        
        //View sınıfı değişkeni yetkilendirme
        ref.presenterNesensi = presenter
        
        //Presenter sınıfı değişkenleri yetkilendirme
        ref.presenterNesensi?.interactor = Interactor()
        ref.presenterNesensi?.view = ref
        
        //Interactor sınıufı değişkeni yetkilendirme
        ref.presenterNesensi?.interactor?.presenter = presenter
    }
}
