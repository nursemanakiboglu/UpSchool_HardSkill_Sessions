//
//  ViewController.swift
//  UsingViper
//
//  Created by Nursema Nakiboğlu on 30.04.2022.
//


import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var labelSonuc: UILabel!
    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var textField2: UITextField!
    
    var presenterNesensi:ViewToPresenterProtocol?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        labelSonuc.text = "0"
        Router.createModule(ref: self)
    }

    @IBAction func toplaButon(_ sender: Any)
    {
        //kontrollü şekilde textfiellerden veri alma
        if let sayi1 = textField1.text,let sayi2 = textField2.text
        {
            /*
            //string ifadelerimzi integer a dönüştürüyoruz
            if let s1 = Int(sayi1), let s2 = Int(sayi2)
            {
                let toplam = s1 + s2
                labelSonuc.text = String(toplam)
            }
             */
            presenterNesensi?.toplamaYap(sayi1: sayi1, sayi2: sayi2)
        }
    }
    
    @IBAction func carpButon(_ sender: Any)
    {
        if let sayi1 = textField1.text,let sayi2 = textField2.text
        {
            
                /*
                //string ifadelerimzi integer a dönüştürüyoruz
                if let s1 = Int(sayi1), let s2 = Int(sayi2)
                {
                    let carpma = s1 * s2
                    labelSonuc.text = String(carpma)
                }
                 */
            presenterNesensi?.carpmaYap(sayi1: sayi1, sayi2: sayi2)
        }

    }
}

extension ViewController : PresenterToViewProtocol
{
    func vieweVeriGönder(sonuc: String)
    {
        labelSonuc.text = sonuc
    }
}
