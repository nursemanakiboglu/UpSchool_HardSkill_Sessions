//
//  ResultScreenVc.swift
//  WorkStructure
//
//  Created by Nursema Nakiboğlu on 20.04.2022.
//

import UIKit

class ResultScreenVc: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()


    }
    
    @IBAction func offClick(_ sender: Any)
    {
        self.dismiss(animated: true)
    }
}
