//
//  ViewController.swift
//  WorkStructure
//
//  Created by Nursema Nakiboğlu on 20.04.2022.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var labelMainPage: UILabel!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // sayfa açıldığında sadece bir kere çalışır.
        print( "viewDidload is worked")
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        print( "viewWillAppear is worked")
        //sayfa her göründüğü zaman çalışır
        //Bu sayfaya geri dönüldüğünde de çalışır
    }

    override func viewWillDisappear(_ animated: Bool)
    {
        print( "viewWillDisappear is worked")
    }

    @IBAction func startClick(_ sender: Any)
    {
        let person = Persons(name:  "Nursema", age: 24, height: 1.72, single: true)
        //labelMainPage.text = "Hello"
        performSegue(withIdentifier: "switchtogamescreen", sender:person) // yazılan string verilen id ile aynı olmak zorunda yoksa hata çıkar
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    //methoddur
    //Any bütün türleri kapsar yani string,double,int,char...
    // segue ise geçiş yapacağımız sayfanın id sini kullandığımız yapıdır
    {
        print("Prepare method is worked")
        
        if segue.identifier ==  "switchtogamescreen"
        {
            print( "SwitchToGameScreen is worked ")
            
            if let data = sender as? Persons
            {
                let gidilecekVC = segue.destination as! GameScreenVC //var olan sınıfa dönüşüm yapılıyor
                gidilecekVC.person = data
            }
        }
    }
    
    @IBAction func clickAdd(_ sender: Any)
    {
        print("Add is clicked")
    }
    @IBAction func clickExit(_ sender: Any)
    {
        print("Exit is clicked")
    }
}

