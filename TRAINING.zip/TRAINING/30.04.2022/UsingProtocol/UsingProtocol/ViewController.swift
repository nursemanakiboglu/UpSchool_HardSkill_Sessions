/*
 ViewController.swift
 UsingProtocol

 Created by Nursema Nakiboğlu on 30.04.2022.
 
 -----------------

 View: ViewController sayfasıdır.Sadece arayüzde verileri göstermek için kullanılır.Kullanıcıya gösterilecek veriler Presenter tarafından sağlanır.
 
 Presenter: Aracı ve yönetici katmandır. Interactor ve view arasındaki işlemleri yürütmeyi sağlar. Katmanlar arası iletişimi sağlar.
 
 Interactor: Veritabanını ve kodları çalıştıracağımız yerdir. API işlemleri burada yapılır.
 
 Entity: Modelimizi yani sınıfımızı temsil eder.
 
 Router: Sayfa geçişleri için ve tüm katmanların iletişim alt yapısını oluşturmak için sağlanan yapıdır.
 
 İletişim PROTOCOLLERLE sağlanır.
-------------------
 -ilk olarak çatı protocol oluşturulur.
 -Bu oluşturulan protokolün methodu olur ve bu methodu kullanıcağımız yere koyarız.
 -Sonra methodu tetiklemeliyiz.
 -Tetiklemek için oluştutulan protokolden bir nesne oluşturmaya ihtiyac vardır.
 -Son olarak da nesneye yetki vermek gerekir.
-------------------
 -Oluşturulan protokol sınıfa eklenir
 -Sınıf; nerden veri almak istiyorsak oraya eklenir.
 -Nerden veri göndermek isteniyorsa ordan tetiklenecek.
*/

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var labelSonuc: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    //herhngi bir veri göndermeden diğer sayfaya geçiş yapmak
    @IBAction func butonGecis(_ sender: Any)
    {
        performSegue(withIdentifier: "toDetail", sender: nil)
    }
    
    //veri göndererek diğer sayfaya geçiş yapmak
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "toDetail"
        {
            let gidilecekVC = segue.destination as! DetailVC
            //yetkilendirme
            gidilecekVC.delegate = self
        }
    }
}

//Veri almak için Protokol kullanıldı
extension ViewController:DetailVCtoViewController
{
    func veriGonder(mesaj: String)
    {
        //gelen mesajı label'a aktarır
        labelSonuc.text = mesaj
    }
}
