//
//  ViewController.swift
//  WidgetsKullanimi2
//
//  Created by Nursema Nakiboğlu on 22.04.2022.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var labelResult: UILabel!
    @IBOutlet weak var textfieldInput: UITextField!
    @IBOutlet weak var mSwitch: UISwitch!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonDo(_ sender: Any)
    {
        if let receivedData = textfieldInput.text //text methodu çift taraflı çalışır hem veri alır hem de veri gönderir
        {
            labelResult.text = receivedData
        }
    }
    @IBAction func buttonResim1(_ sender: Any)
    {
        imageView.image = UIImage(named: "resim1")
    }
    @IBAction func buttonResim2(_ sender: Any)
    {
        imageView.image = UIImage(named: "resim2")
    }
    @IBAction func switchChangeLocation(_ sender: UISwitch)
    {
        if sender.isOn
        {
            print("Switch: ON")
        }
        else
        {
            print("Switch: OFF")
        }
    }
    
    @IBAction func segmentChangeControl(_ sender: UISegmentedControl)
    {
        let selectedIndex = sender.selectedSegmentIndex
        let selectedTitle = sender.titleForSegment(at: selectedIndex)
        print("Selection: \(selectedTitle!)")
    }
    
    @IBAction func buttonShow(_ sender: Any)
    {
        print("Show switch status: \(mSwitch.isOn)")
    }

}

