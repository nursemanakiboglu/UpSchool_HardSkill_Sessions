//
//  ViewController.swift
//  ViperKullanimi
//
//  Created by Nursema Nakiboğlu on 8.05.2022.

/*
 1-Toplama ve Çarpma buronuna bastığımızda aktarılacak olan bilgi view!den presenter'a gidecek.
 2-Presentar bilgiyi interactor'a aktaracak.
 3-Interactorda bilgi işlenecek ve interactor bilgiyi geri gönderip arayüzde görüntülenmesini sağlıyacak
 */

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var labelSonuc: UILabel!
    @IBOutlet weak var textfieldsayi1: UITextField!
    @IBOutlet weak var textfieldsayi2: UITextField!
    
    var presenterNesensi:ViewToPresenterProtocol?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        labelSonuc.text = "0"
        Router.createModule(ref: self)
    }

    @IBAction func butonToplama(_ sender: Any)
    {
        //kontrollü şekilde textfiellerden veri alma
        if let sayi1 = textfieldsayi1.text,let sayi2 = textfieldsayi2.text
        {
            /*
            //string ifadelerimzi integer a dönüştürüyoruz
            if let s1 = Int(sayi1), let s2 = Int(sayi2)
            {
                let toplam = s1 + s2
                labelSonuc.text = String(toplam)
            }
             */
            
            presenterNesensi?.toplamaYap(sayi1: sayi1, sayi2: sayi2)
        }
        
    }
    
    @IBAction func butonCarpma(_ sender: Any)
    {
        //kontrollü şekilde textfiellerden veri alma
        if let sayi1 = textfieldsayi1.text,let sayi2 = textfieldsayi2.text
        {
            /*
            //string ifadelerimzi integer a dönüştürüyoruz
            if let s1 = Int(sayi1), let s2 = Int(sayi2)
            {
                let carpma = s1 * s2
                labelSonuc.text = String(carpma)
            }
             */
            presenterNesensi?.carpmaYap(sayi1: sayi1, sayi2: sayi2)
        }
    }
}

